package com.vrb.apps.test.models

class Person (val id: String,
              val firstname: String,
              val lastname: String,
              val placeOfWork: String,
              val position: String?,
              val linkPDF: String,
              var isBookmarked: Boolean = false,
              var note: String?)